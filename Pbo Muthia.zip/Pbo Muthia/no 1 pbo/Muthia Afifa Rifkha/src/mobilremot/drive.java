/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mobilremot;


public class drive {
    int kecepatan;
    int arah;
    int kecepatanmaks;
    boolean bergerak;

    public drive(){
        kecepatan = 0;
        arah = 0;
        bergerak = false;
        kecepatanmaks = 100;
    }

    public int getkecepatan() {
        return kecepatan;
    }

    public void setkecepatan(int kecepatan) {
        if (kecepatan >= 0 && kecepatan <= kecepatanmaks) {
            this.kecepatan = kecepatan;
            if (bergerak) {
                updatearah();
            }
        }
    }

    public int getarah() {
        return arah;
    }

    public void setarah(int arah) {
        if (arah >= 0 && arah <= 360) {
            this.arah = arah;
            if (bergerak) {
                updatearah();
            }
        }
    }

    public boolean bergerak() {
        return bergerak;
    }

    public void start() {
        bergerak = true;
        updatearah();
    }

    public void stop() {
        bergerak = false;
    }

    public void setkecepatanmaks(int kecepatanmaks) {
        this.kecepatanmaks = kecepatanmaks;
    }

    public void useNitrous() {
        if (kecepatan < kecepatanmaks) {
            kecepatan += 20;
            if (kecepatan > kecepatanmaks) {
                System.out.println("Cannot use nitrous, kecepatan has reached max kecepatan");
                kecepatan = kecepatanmaks;
            }
        }
        if (bergerak) {
            updatearah();
        }
    }

    public void updatearah() {
        if (kecepatan == 0) {
            return;
        }
        int newarah = arah + kecepatan / 10;
        if (newarah > 360) {
            newarah = newarah - 360;
        }
        arah = newarah;
    }
}    
