/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mobilremot;

/**
 *
 * @author Acer
 */
public class mobilrc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          drive myCar = new drive();
        
        myCar.start();
        myCar.setkecepatan(20);
        myCar.setarah(180);
        
        
        System.out.println("Kecepatan :" + myCar.getkecepatan());
        System.out.println("Arah :  " + myCar.getarah());
       
        
        myCar.useNitrous();
        
        System.out.println("Kecepatan setelah menggunakan nitro:" + myCar.getkecepatan());
        System.out.println("Arah setelah menggunakan nitro:  " + myCar.getarah());
       
    }
    
}
