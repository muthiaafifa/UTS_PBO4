public class rekursifprogram {
    
    public int factorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * factorial(n - 1);
        }
    }

    public int fibonacci(int n) {
        if (n == 0 || n == 1) {
            return n;
        } else {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }

    public static void main(String[] args) {
        rekursifprogram rp = new rekursifprogram();
        int n = 6;
        int hasilfaktorial = rp.factorial(n);
        System.out.println("Faktorial dari " + n + " yaitu " + hasilfaktorial);
        int hasilfibonacci = rp.fibonacci(n);
        System.out.println("Fibonacci dari " + n + " yaitu " + hasilfibonacci);
    }
}
